#!/usr/bin/env python3
"""Offline source assertions; not a substitute for Android compilation or device tests."""
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
checks = []

def check(name, pred):
    checks.append((name, bool(pred)))

main = (ROOT/'app/src/main/java/com/bharathlink/app/MainActivity.kt').read_text()
bridge = (ROOT/'app/src/main/java/com/bharathlink/app/bridge/TrustedWebMessageBridge.kt').read_text()
origin = (ROOT/'app/src/main/java/com/bharathlink/app/util/OriginPolicy.kt').read_text()
service = (ROOT/'app/src/main/java/com/bharathlink/app/service/IncomingCallForegroundService.kt').read_text()
store = (ROOT/'app/src/main/java/com/bharathlink/app/service/CallStateStore.kt').read_text()
keystore = (ROOT/'app/src/main/java/com/bharathlink/app/security/KeystoreManager.kt').read_text()
manifest_path = ROOT/'app/src/main/AndroidManifest.xml'
manifest = manifest_path.read_text()
network = (ROOT/'app/src/main/res/xml/network_security_config.xml').read_text()
workflow = (ROOT/'.github/workflows/android-test-apk.yml').read_text()

for xmlfile in [manifest_path, ROOT/'app/src/main/res/xml/network_security_config.xml',
                ROOT/'app/src/main/res/drawable/ic_bharathlink.xml']:
    try:
        ET.parse(xmlfile)
        check(f'XML parses: {xmlfile.name}', True)
    except ET.ParseError:
        check(f'XML parses: {xmlfile.name}', False)

all_source = '\n'.join(p.read_text() for p in (ROOT/'app/src/main/java').rglob('*.kt'))
check('Legacy JavascriptInterface absent', '@JavascriptInterface' not in all_source)
check('Legacy addJavascriptInterface absent', 'addJavascriptInterface(' not in all_source)
check('Origin-scoped web messaging used', 'WebViewCompat.addWebMessageListener' in bridge)
check('Main-frame checks present', '!isMainFrame' in bridge)
check('Current page matches source origin', 'source != current' in bridge)
check('Native privileged secret API disabled', '"SECRET_API_DISABLED"' in bridge)
check('Native bridge fails closed on old WebViews', 'WEB_MESSAGE_LISTENER' in bridge and 'return false' in bridge)
check('Original broad cloud suffix removed', 'TRUSTED_HOST_SUFFIXES' not in all_source)
check('Trusted host exact membership', 'host !in trustedHosts' in origin)
check('No insecure local dev origins', 'localhost' not in origin and '10.0.2.2' not in origin)
check('HTTPS scheme enforced', 'uri.scheme.equals("https"' in origin)
check('Initial deep link is validated', 'OriginPolicy.isAllowedPageUrl(requested)' in main)
check('Media permission request checks origin', 'isTrustedMediaRequest(request)' in main)
check('Unknown WebRTC resources denied', 'request.resources.all { it in allowed }' in main)
check('Media runtime permissions requested on use', 'mediaPermissionLauncher.launch' in main)
check('No auto camera/mic permission at startup', 'requestPermissionsLauncher' not in main)
check('Navigations reject unsafe URLs', 'openExternalIfSafe(url)' in main)
check('Intent JSON encoded by JSONObject', 'JSONObject().put("callId", id)' in main)
check('Manifest avoids restricted phoneCall foreground type', '"phoneCall|microphone"' not in manifest)
check('ShortService used', 'android:foregroundServiceType="shortService"' in manifest)
check('Call Answer delivered by direct activity PendingIntent', 'PendingIntent.getActivity(this, 1, answer' in service)
check('Answer validates one-shot pending call', 'CallStateStore.consumePendingCall' in main)
check('Call alert bounded by timeout', 'RING_TIMEOUT_MS = 45_000L' in service)
check('CallStateStore expiry exists', 'MAX_AGE_MS = 60_000L' in store)
check('Keystore no automatic destructive vault-reset', 'resetting vault' not in keystore)
check('Keystore migrates only after commit', 'if (editor.commit())' in keystore)
check('Cleartext traffic blocked', 'cleartextTrafficPermitted="false"' in network)
check('Untrusted debug CAs not allowed', 'debug-overrides' not in network)
check('App launcher icon exists', (ROOT/'app/src/main/res/drawable/ic_bharathlink.xml').is_file())
check('CI unit test + APK build configured', ':app:testDebugUnitTest :app:assembleDebug' in workflow)
check('CI uploads the debug artifact', 'app/build/outputs/apk/debug/app-debug.apk' in workflow)

for name, ok in checks:
    print(f'{"PASS" if ok else "FAIL"}: {name}')
print(f'OFFLINE_STATIC_CHECKS_PASS={sum(ok for _, ok in checks)}/{len(checks)}')
raise SystemExit(0 if all(ok for _, ok in checks) else 1)
