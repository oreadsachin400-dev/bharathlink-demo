# BharathLink V36HF — SECURITY-PATCHED Android TEST Source

**Scope:** TEST-only Android WebView wrapper, not an approved production app or a verified APK.

## What this source contains

- `MainActivity.kt`: HTTPS-only trusted main-frame navigation, restricted WebRTC permission grants, call Answer dispatch.
- `bridge/TrustedWebMessageBridge.kt`: origin- and main-frame-bound `WebViewCompat.addWebMessageListener`, with no `addJavascriptInterface` fallback.
- `util/OriginPolicy.kt`: exact host allowlist (two current TEST origins), pure JVM-testable.
- `service/IncomingCallForegroundService.kt`: bounded, notification-based TEST ringing using Android 14 `shortService`; no claim of persistent background WebRTC audio.
- `service/CallStateStore.kt`: opaque call-ID match and one-shot expiry for Answer notification actions.
- `security/KeystoreManager.kt`: existing optional encrypted-pref helper, made fail-closed on vault init; it is NOT exposed to the WebView.
- `.github/workflows/android-test-apk.yml`: branch-scoped CI test/build/artifact workflow.
- `scripts/run_static_checks.py` and `app/src/test/.../OriginPolicyTest.kt`: repeatable static/unit regression checks.

## Build

Requires: Android Studio with SDK 34 and JDK 17, or Gradle **8.6** and Android SDK 34. For the command line:

```sh
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug
```

The original ZIP contained `gradle/wrapper/gradle-wrapper.properties` but **did not contain `gradlew` or `gradle-wrapper.jar`**, so `./gradlew` does not work until a valid wrapper is generated. The CI workflow installs Gradle 8.6 instead.

APK output after a **successful real Android build**:
`app/build/outputs/apk/debug/app-debug.apk`

The debug application ID uses `.test`, and this code is explicitly NOT production-approved. No compiled APK is bundled here.

## Use of the native WebView bridge

The legacy Android `@JavascriptInterface` allowed any WebView frame to call native secret APIs. It was removed entirely. Pages on exact trusted origins may now use `window.BharathLinkHost.postMessage(JSON.stringify({id, action, params}))`. An asynchronous compatibility helper `window.BharathLinkNativeBridge` may be installed through document-start script where supported.

Actions currently supported: `ping`, `vibrate`, `incomingCallStart`, `incomingCallStop`. The original `getSecureToken`, `saveSecureToken`, and `clearSecureStorage` JavaScript methods are **intentionally disabled**. They must not be re-enabled without a secure, code-reviewed authentication/session design. Prior synchronous token-calling web code requires adaptation. This ZIP does NOT contain the actual hosted web frontend, so its integration compatibility has not been proven.

A secure message API unavailable on the installed Android System WebView results in **no native bridge**; it never falls back to insecure `addJavascriptInterface`.

## Allowed navigation origins

- `https://ais-dev-rct6nb4sdglft27shfgdyd-143017817560.asia-southeast1.run.app`
- `https://bharathlink-20-test.netlify.app`

Only exact HTTPS origins are trusted; other `run.app`, `supabase.co`, Firebase, loopback, blob/data, and lookalike domains are not. Any future TEST URL must be explicitly reviewed and added to `OriginPolicy.kt` and its tests. Allowlisting an HTTPS host alone does not defend against code compromise/XSS on that host.

## Incoming call behavior

Notification **Answer** directly opens `MainActivity`; it checks the unexpired pending call ID before dispatching `bharathlink:answerCall` to the trusted loaded web page. Notification **Decline** stops an active matching alert. Ringing is limited to 45 seconds. Android versions 12+ may restrict background starts, and Android 14+ may restrict full-screen notifications. An FCM/Telecom-compliant background calling solution has **not** been implemented. These actions do not answer a WebRTC call on their own; the hosted web app must handle the custom event.

## Test evidence

- `python scripts/run_static_checks.py`: **34/34 checks PASS** (source + XML assertions).
- Standalone local `kotlinc` + JVM policy harness: **29/29 cases PASS** (see `TEST_RESULTS.md`).
- Android Gradle compilation: **NOT RUN** in this environment (no Android SDK/Gradle).
- Emulator or physical phone: **NOT RUN**.
- Live signaling, E2EE, email, payment, auth, push and WebView/frontend protocol: **NOT VERIFIED**.

## Next gate

Commit this TEST source to the intended **existing TEST branch** (not main), run `android-test-apk.yml` in GitHub Actions, verify the output artifact and install it on two phones. Perform end-to-end tests, particularly the web bridge API adaptation, WebRTC media permissions, Answer/Decline behavior, and authentication-session continuity. Never represent offline checks as an Android PASS.

**Link behavior:** External browser/UPI/tel/mailto navigation is restricted to supported schemes and must be initiated by a WebView-reported user gesture. Some JavaScript-initiated payment handoffs may require a reviewed design change.

## Existing connected GitHub TEST branch — compatibility warning

Read-only inspection confirmed `oreadsachin400-dev/bharathlink-demo` → `bharathlink-android-test-build` currently builds a **different** Java/Groovy wrapper under `BharathLink-Android/` with Android SDK 35 and a different package ID. **Do not unzip this Kotlin SDK34 project over that folder or replace its working CI job without a review/controlled migration.** No GitHub push or merge was performed. See `AUDIT_FINDINGS.md` for the exact comparison.
