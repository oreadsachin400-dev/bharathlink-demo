# ProGuard rules for BharathLink Android TEST App
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.bharathlink.app.bridge.** { *; }
-keepclassmembers class com.bharathlink.app.bridge.** { *; }

# Security Crypto rules
-keep class androidx.security.crypto.** { *; }
