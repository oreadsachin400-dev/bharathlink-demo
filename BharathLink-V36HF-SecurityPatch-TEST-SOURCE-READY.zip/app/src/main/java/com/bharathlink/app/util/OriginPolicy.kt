package com.bharathlink.app.util

import java.net.URI
import java.util.Locale

/**
 * Explicit HTTPS main-frame allowlist. No suffix matching, loopback, data/blob,
 * wildcards, or arbitrary cloud tenants. Keep in sync with WebView message rules.
 */
object OriginPolicy {
    private const val AI_STUDIO_TEST_HOST = "ais-dev-rct6nb4sdglft27shfgdyd-143017817560.asia-southeast1.run.app"
    private const val NETLIFY_TEST_HOST = "bharathlink-20-test.netlify.app"
    private val trustedHosts = setOf(AI_STUDIO_TEST_HOST, NETLIFY_TEST_HOST)
    val trustedOrigins: Set<String> = trustedHosts.mapTo(linkedSetOf()) { "https://$it" }
    const val defaultPage = "https://ais-dev-rct6nb4sdglft27shfgdyd-143017817560.asia-southeast1.run.app"

    fun originForPage(rawUrl: String?): String? {
        if (rawUrl.isNullOrBlank()) return null
        val uri = try { URI(rawUrl) } catch (_: Exception) { return null }
        if (!uri.isAbsolute || !uri.scheme.equals("https", ignoreCase = true)) return null
        if (uri.rawUserInfo != null || uri.port != -1 && uri.port != 443) return null
        val host = uri.host?.lowercase(Locale.ROOT) ?: return null
        if (host !in trustedHosts) return null
        // Reject opaque and malformed URL forms rather than guessing an origin.
        if (uri.isOpaque || uri.rawAuthority.isNullOrEmpty()) return null
        return "https://$host"
    }

    fun isAllowedPageUrl(rawUrl: String?): Boolean = originForPage(rawUrl) != null

    fun isSafeExternalUrl(rawUrl: String?): Boolean {
        if (rawUrl.isNullOrBlank()) return false
        val uri = try { URI(rawUrl) } catch (_: Exception) { return false }
        val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return false
        return when (scheme) {
            "https", "http" -> uri.host != null && uri.rawUserInfo == null
            "mailto", "tel", "upi" -> !uri.isOpaque || uri.schemeSpecificPart.isNotEmpty()
            else -> false
        }
    }
}
