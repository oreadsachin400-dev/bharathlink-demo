package com.bharathlink.app.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/**
 * Android Keystore-backed secure storage for BharathLink session material,
 * auth tokens, and E2EE key pairs.
 *
 * Implements:
 * 1. Android Keystore-managed AES-GCM encryption (hardware backing device-dependent)
 * 2. Best-effort migration from previously known local preferences
 * 3. Explicit preference wipe on logout (does not clear WebView-origin storage)
 */
class KeystoreManager(private val context: Context) {

    companion object {
        private const val TAG = "KeystoreManager"
        private const val SECURE_PREFS_NAME = "bharathlink_keystore_vault"
        private const val LEGACY_PREFS_NAME = "bharathlink_legacy_prefs"
        private const val MIGRATION_DONE_KEY = "__migration_completed_v36"
    }

    private val masterKeyAlias: String by lazy {
        val keyGenSpec = MasterKeys.AES256_GCM_SPEC
        MasterKeys.getOrCreate(keyGenSpec)
    }

    private val securePrefs: SharedPreferences by lazy {
        // Fail closed if Android Keystore is unavailable/corrupted; never silently wipe vault.
        EncryptedSharedPreferences.create(
            SECURE_PREFS_NAME,
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    init {
        performMigrationIfNeeded()
    }

    /**
     * Store sensitive credential or E2EE token in Keystore-backed vault
     */
    fun saveToken(key: String, value: String): Boolean {
        return try {
            securePrefs.edit().putString(key, value).commit()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save secure token for key: $key", e)
            false
        }
    }

    /**
     * Retrieve sensitive credential or E2EE token
     */
    fun getToken(key: String): String? {
        return try {
            securePrefs.getString(key, null)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read secure token for key: $key", e)
            null
        }
    }

    /**
     * Explicit wipe on logout: guarantees no session or cryptographic artifacts persist
     */
    fun clearAll(): Boolean {
        return try {
            val secureCleared = securePrefs.edit().clear().commit()
            val legacyCleared = context.getSharedPreferences(LEGACY_PREFS_NAME, Context.MODE_PRIVATE)
                .edit().clear().commit()
            if (secureCleared && legacyCleared) Log.i(TAG, "Keystore preferences cleared")
            secureCleared && legacyCleared
        } catch (e: Exception) {
            Log.e(TAG, "Failed to clear Keystore vault on logout", e)
            false
        }
    }

    /**
     * Detects older unencrypted preferences from previous builds and migrates them
     * into Keystore-backed storage before wiping the legacy file.
     */
    private fun performMigrationIfNeeded() {
        try {
            val legacyPrefs = context.getSharedPreferences(LEGACY_PREFS_NAME, Context.MODE_PRIVATE)
            if (legacyPrefs.all.isEmpty()) return

            val isMigrated = securePrefs.getBoolean(MIGRATION_DONE_KEY, false)
            if (!isMigrated) {
                Log.i(TAG, "Migrating legacy preferences to Android Keystore...")
                val editor = securePrefs.edit()
                for ((k, v) in legacyPrefs.all) {
                    if (v is String) {
                        editor.putString(k, v)
                    }
                }
                editor.putBoolean(MIGRATION_DONE_KEY, true)
                if (editor.commit()) {
                    if (!legacyPrefs.edit().clear().commit()) {
                        Log.w(TAG, "Legacy preferences could not be wiped after migration")
                    }
                } else {
                    Log.e(TAG, "Secure migration commit failed: retaining legacy storage")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Legacy migration check encountered an exception", e)
        }
    }
}
