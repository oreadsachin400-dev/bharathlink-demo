package com.bharathlink.app.bridge

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.webkit.WebView
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.bharathlink.app.service.IncomingCallForegroundService
import com.bharathlink.app.util.OriginPolicy
import org.json.JSONObject

/** No addJavascriptInterface: only HTTPS allowlisted main frame may send messages. */
class TrustedWebMessageBridge(
    private val context: Context,
    private val webView: WebView
) {
    companion object {
        private const val TAG = "BharathLinkBridge"
        private const val MAX_MESSAGE = 4096
        private const val MAX_CALL_ID = 128
        private const val MAX_CALLER_NAME = 100
    }

    /** Fail closed on older WebViews that cannot enforce origin-scoped listeners. */
    fun install(): Boolean {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            Log.w(TAG, "Secure WebMessageListener unavailable: native bridge disabled")
            return false
        }
        WebViewCompat.addWebMessageListener(
            webView, "BharathLinkHost", OriginPolicy.trustedOrigins
        ) { view: WebView, message: WebMessageCompat, sourceOrigin: Uri,
            isMainFrame: Boolean, replyProxy: JavaScriptReplyProxy ->
            val source = OriginPolicy.originForPage(sourceOrigin.toString())
            val current = OriginPolicy.originForPage(view.url)
            // Re-check at dispatch to close redirect and iframe privilege escalation.
            if (!isMainFrame || current == null || source != current) {
                Log.w(TAG, "Rejected native bridge message from non-trusted frame")
            } else {
                val payload = try { message.data } catch (_: Exception) { null }
                if (payload != null && payload.length <= MAX_MESSAGE) {
                    handleMessage(payload, replyProxy)
                } else {
                    Log.w(TAG, "Dropped oversized or non-string bridge message")
                }
            }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            // Optional compatibility adapter; all calls are ASYNCHRONOUS.
            WebViewCompat.addDocumentStartJavaScript(
                webView, compatibilityScript, OriginPolicy.trustedOrigins
            )
        }
        return true
    }

    private var lastIncomingCallStartMs = 0L

    private fun handleMessage(data: String, reply: JavaScriptReplyProxy) {
        var id = ""
        try {
            val request = JSONObject(data)
            id = request.optString("id", "").take(64)
            val action = request.optString("action")
            val params = request.optJSONObject("params") ?: JSONObject()
            val value: Any = when (action) {
                "ping" -> "BharathLink/36HF-secure-test"
                "vibrate" -> {
                    vibrate(params.optLong("durationMs", 75L).coerceIn(10L, 1000L))
                    true
                }
                "incomingCallStart" -> {
                    val callId = params.optString("callId")
                    val callerName = params.optString("callerName")
                    val callType = params.optString("callType")
                    require(callId.length in 1..MAX_CALL_ID && callId.all { it.isLetterOrDigit() || it in "-_:." }) {
                        "INVALID_CALL_ID"
                    }
                    require(callerName.isNotBlank() && callerName.length <= MAX_CALLER_NAME) { "INVALID_CALLER_NAME" }
                    require(callType == "audio" || callType == "video") { "INVALID_CALL_TYPE" }
                    require(callerName.none { Character.isISOControl(it) }) { "INVALID_CALLER_NAME" }
                    val now = android.os.SystemClock.elapsedRealtime()
                    require(lastIncomingCallStartMs == 0L || now - lastIncomingCallStartMs >= 5000L) { "RATE_LIMITED" }
                    IncomingCallForegroundService.startCall(context, callerName, callType, callId)
                    lastIncomingCallStartMs = now
                    true
                }
                "incomingCallStop" -> {
                    val callId = params.optString("callId")
                    require(callId.length in 1..MAX_CALL_ID) { "INVALID_CALL_ID" }
                    IncomingCallForegroundService.stopCall(context, callId)
                    true
                }
                // A page XSS can read any token exposed to page JS. Secret APIs remain disabled.
                "getSecureToken", "saveSecureToken", "clearSecureStorage" ->
                    throw IllegalArgumentException("SECRET_API_DISABLED")
                else -> throw IllegalArgumentException("UNKNOWN_ACTION")
            }
            reply.postMessage(JSONObject().put("id", id).put("ok", true).put("value", value).toString())
        } catch (ex: Exception) {
            val code = when (ex.message) {
                "SECRET_API_DISABLED", "INVALID_CALL_ID", "INVALID_CALLER_NAME", "INVALID_CALL_TYPE", "RATE_LIMITED", "UNKNOWN_ACTION" -> ex.message
                else -> "NATIVE_ACTION_FAILED"
            }
            Log.w(TAG, "Bridge action rejected: $code")
            reply.postMessage(JSONObject().put("id", id).put("ok", false).put("error", code).toString())
        }
    }

    private fun vibrate(duration: Long) {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    /** Used by trusted app activity events; the current top-level page must still be allowed. */
    fun dispatchWebEvent(name: String, payload: JSONObject = JSONObject()) {
        webView.post {
            if (OriginPolicy.isAllowedPageUrl(webView.url)) {
                val script = "window.dispatchEvent(new CustomEvent(${JSONObject.quote(name)}, {detail: ${payload}}));"
                webView.evaluateJavascript(script, null)
            }
        }
    }

    private val compatibilityScript = """
        (() => {
          'use strict';
          const host = window.BharathLinkHost;
          if (!host || window.BharathLinkNativeBridge) return;
          let seq = 0;
          const waiting = new Map();
          host.onmessage = (event) => {
            try {
              const msg = JSON.parse(event.data);
              const item = waiting.get(msg.id);
              if (!item) return;
              waiting.delete(msg.id);
              msg.ok ? item.resolve(msg.value) : item.reject(new Error(msg.error || 'NATIVE_ACTION_FAILED'));
            } catch (_) { /* malformed reply is ignored */ }
          };
          const call = (action, params = {}) => new Promise((resolve, reject) => {
            const id = String(++seq);
            if (waiting.size >= 32) { reject(new Error('BRIDGE_BUSY')); return; }
            waiting.set(id, {resolve, reject});
            host.postMessage(JSON.stringify({id, action, params}));
          });
          Object.defineProperty(window, 'BharathLinkNativeBridge', {
            configurable: false, writable: false,
            value: Object.freeze({
              isAndroidBridgeActive: () => true,
              getBridgeVersion: () => '36HF-secure-test',
              vibrateDevice: (durationMs) => call('vibrate', {durationMs}),
              triggerIncomingCall: (callerName, callType, callId) =>
                call('incomingCallStart', {callerName, callType, callId}),
              stopIncomingCall: (callId) => call('incomingCallStop', {callId}),
              // NOT available until an explicitly reviewed secure session protocol is deployed.
              saveSecureToken: () => Promise.reject(new Error('SECRET_API_DISABLED')),
              getSecureToken: () => Promise.reject(new Error('SECRET_API_DISABLED')),
              clearSecureStorage: () => Promise.reject(new Error('SECRET_API_DISABLED'))
            })
          });
        })();
    """.trimIndent()
}
