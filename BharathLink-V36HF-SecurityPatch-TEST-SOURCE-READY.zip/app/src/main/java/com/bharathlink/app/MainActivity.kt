package com.bharathlink.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bharathlink.app.bridge.TrustedWebMessageBridge
import com.bharathlink.app.service.CallStateStore
import com.bharathlink.app.service.IncomingCallForegroundService
import com.bharathlink.app.util.OriginPolicy
import org.json.JSONObject

/** V36HF TEST: origin-scoped bridge, deny-by-default media permissions, trusted URLs only. */
class MainActivity : AppCompatActivity() {
    companion object { private const val TAG = "BharathLinkActivity" }

    private lateinit var webView: WebView
    private lateinit var bridge: TrustedWebMessageBridge
    private var pendingPermission: PermissionRequest? = null
    private var pendingAnswerCallId: String? = null
    private var pageLoaded = false

    private val mediaPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val request = pendingPermission
        pendingPermission = null
        if (request != null) respondToMediaPermission(request)
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> Log.i(TAG, "Notification permission granted: $granted") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureWebView()
        setupBackNavigation()
        handleCallIntent(intent)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView = WebView(this)
        setContentView(webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            safeBrowsingEnabled = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            userAgentString = "$userAgentString BharathLink-Android/36HF-TEST"
        }

        bridge = TrustedWebMessageBridge(applicationContext, webView)
        bridge.install() // Secure feature not supported -> no native bridge; web UI remains usable.

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (!isTrustedMediaRequest(request)) {
                        request.deny()
                        return@runOnUiThread
                    }
                    if (pendingPermission != null) {
                        request.deny()
                        return@runOnUiThread
                    }
                    val needed = mutableListOf<String>()
                    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) &&
                        !hasPermission(Manifest.permission.CAMERA)
                    ) needed.add(Manifest.permission.CAMERA)
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) &&
                        !hasPermission(Manifest.permission.RECORD_AUDIO)
                    ) needed.add(Manifest.permission.RECORD_AUDIO)
                    if (needed.isEmpty()) respondToMediaPermission(request)
                    else {
                        pendingPermission = request
                        mediaPermissionLauncher.launch(needed.toTypedArray())
                    }
                }
            }
            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingPermission === request) pendingPermission = null
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (OriginPolicy.isAllowedPageUrl(url)) return false
                // An embedded frame cannot trigger external applications or browser intents.
                if (!request.isForMainFrame) return true
                if (request.hasGesture()) openExternalIfSafe(url)
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                pageLoaded = false
                if (!OriginPolicy.isAllowedPageUrl(url)) {
                    view.stopLoading()
                    view.loadUrl(OriginPolicy.defaultPage)
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (!OriginPolicy.isAllowedPageUrl(url)) return
                pageLoaded = true
                dispatchPendingAnswer()
            }
        }

        // Only a validated https deep link can select an initial app URL.
        val requested = intent?.dataString
        val initialUrl = if (OriginPolicy.isAllowedPageUrl(requested)) requested!!
                         else OriginPolicy.defaultPage
        webView.loadUrl(initialUrl)
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun isTrustedMediaRequest(request: PermissionRequest): Boolean {
        val source = OriginPolicy.originForPage(request.origin.toString())
        if (source != OriginPolicy.originForPage(webView.url)) return false
        if (!OriginPolicy.isAllowedPageUrl(webView.url)) return false
        val allowed = setOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE, PermissionRequest.RESOURCE_VIDEO_CAPTURE)
        return request.resources.isNotEmpty() && request.resources.all { it in allowed }
    }

    private fun respondToMediaPermission(request: PermissionRequest) {
        if (!isTrustedMediaRequest(request)) {
            request.deny()
            return
        }
        val permitted = request.resources.filter { resource ->
            when (resource) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> hasPermission(Manifest.permission.CAMERA)
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> hasPermission(Manifest.permission.RECORD_AUDIO)
                else -> false
            }
        }
        // All requested resources must be authorized; never grant a broader subset implicitly.
        if (permitted.size == request.resources.size) request.grant(permitted.toTypedArray())
        else request.deny()
    }

    private fun openExternalIfSafe(url: String) {
        if (!OriginPolicy.isSafeExternalUrl(url)) {
            Log.w(TAG, "Blocked external URL scheme")
            return
        }
        try {
            val external = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
            }
            startActivity(external)
        } catch (e: Exception) {
            Toast.makeText(this, "No app available to open this link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleCallIntent(intent)
    }

    private fun handleCallIntent(intent: Intent?) {
        if (intent?.action != IncomingCallForegroundService.ACTION_ANSWER_CALL) return
        val id = intent.getStringExtra(IncomingCallForegroundService.EXTRA_CALL_ID) ?: return
        if (!CallStateStore.consumePendingCall(this, id)) {
            Log.w(TAG, "Rejected unrecognized or expired Answer intent")
            return
        }
        pendingAnswerCallId = id
        IncomingCallForegroundService.stopCall(this, id)
        dispatchPendingAnswer()
    }

    private fun dispatchPendingAnswer() {
        if (!pageLoaded || !OriginPolicy.isAllowedPageUrl(webView.url)) return
        val id = pendingAnswerCallId ?: return
        pendingAnswerCallId = null
        bridge.dispatchWebEvent("bharathlink:answerCall", JSONObject().put("callId", id))
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.onResume()
            bridge.dispatchWebEvent("bharathlink:lifecycle", JSONObject().put("state", "resumed"))
        }
    }

    override fun onPause() {
        if (::webView.isInitialized) {
            bridge.dispatchWebEvent("bharathlink:lifecycle", JSONObject().put("state", "paused"))
            webView.onPause()
        }
        super.onPause()
    }

    override fun onDestroy() {
        pendingPermission?.deny()
        pendingPermission = null
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
