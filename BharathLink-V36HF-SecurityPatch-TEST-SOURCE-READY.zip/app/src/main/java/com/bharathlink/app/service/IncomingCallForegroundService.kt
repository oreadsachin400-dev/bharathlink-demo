package com.bharathlink.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.bharathlink.app.MainActivity
import com.bharathlink.app.R

/**
 * TEST-only incoming-call alert. Not a Telecom-registered self-managed phone service.
 * Uses Android 14 shortService instead of restricted phoneCall/microphone foreground type.
 * Does not host background microphone/camera/WebRTC media.
 */
class IncomingCallForegroundService : Service() {
    companion object {
        private const val TAG = "BharathLinkIncoming"
        private const val CHANNEL_ID = "bharathlink_incoming_calls_v36hf"
        private const val NOTIFICATION_ID = 1001
        private const val RING_TIMEOUT_MS = 45_000L
        const val ACTION_START_INCOMING_CALL = "com.bharathlink.app.action.START_INCOMING_CALL"
        const val ACTION_STOP_INCOMING_CALL = "com.bharathlink.app.action.STOP_INCOMING_CALL"
        const val ACTION_ANSWER_CALL = "com.bharathlink.app.action.ANSWER_CALL"
        const val ACTION_DECLINE_CALL = "com.bharathlink.app.action.DECLINE_CALL"
        const val EXTRA_CALLER_NAME = "extra_caller_name"
        const val EXTRA_CALL_TYPE = "extra_call_type"
        const val EXTRA_CALL_ID = "extra_call_id"

        fun startCall(context: Context, callerName: String, callType: String, callId: String) {
            val intent = Intent(context, IncomingCallForegroundService::class.java).apply {
                action = ACTION_START_INCOMING_CALL
                putExtra(EXTRA_CALLER_NAME, callerName)
                putExtra(EXTRA_CALL_TYPE, callType)
                putExtra(EXTRA_CALL_ID, callId)
            }
            // Android may refuse background FGS starts; callers must handle the exception.
            context.startForegroundService(intent)
        }

        fun stopCall(context: Context, callId: String) {
            val intent = Intent(context, IncomingCallForegroundService::class.java).apply {
                action = ACTION_STOP_INCOMING_CALL
                putExtra(EXTRA_CALL_ID, callId)
            }
            // stopService does not launch a new background FGS.
            context.startService(intent)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var currentCallId: String? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private val timeoutRunnable = Runnable { stopCallAndSelf() }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val callId = intent?.getStringExtra(EXTRA_CALL_ID)
        when (intent?.action) {
            ACTION_START_INCOMING_CALL -> {
                if (callId.isNullOrBlank()) { stopSelf(); return START_NOT_STICKY }
                stopAlert()
                currentCallId = callId
                CallStateStore.setPendingCall(this, callId)
                val callerName = intent.getStringExtra(EXTRA_CALLER_NAME) ?: "BharathLink User"
                val callType = intent.getStringExtra(EXTRA_CALL_TYPE) ?: "audio"
                try {
                    val alert = buildNotification(callerName, callType, callId)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        startForeground(NOTIFICATION_ID, alert, ServiceInfo.FOREGROUND_SERVICE_TYPE_SHORT_SERVICE)
                    } else startForeground(NOTIFICATION_ID, alert)
                    acquireWakeLock()
                    startRinging()
                    handler.postDelayed(timeoutRunnable, RING_TIMEOUT_MS)
                } catch (ex: Exception) {
                    Log.e(TAG, "Foreground notification was blocked", ex)
                    stopCallAndSelf()
                }
            }
            ACTION_STOP_INCOMING_CALL, ACTION_DECLINE_CALL -> {
                if (callId == currentCallId || currentCallId == null) stopCallAndSelf()
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(name: String, type: String, callId: String): Notification {
        val answer = Intent(this, MainActivity::class.java).apply {
            action = ACTION_ANSWER_CALL
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_CALL_ID, callId)
        }
        val answerPending = PendingIntent.getActivity(this, 1, answer,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val decline = Intent(this, IncomingCallForegroundService::class.java).apply {
            action = ACTION_DECLINE_CALL
            putExtra(EXTRA_CALL_ID, callId)
        }
        val declinePending = PendingIntent.getService(this, 2, decline,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_phone_call)
            .setContentTitle(getString(R.string.incoming_call_title, type.replaceFirstChar { it.uppercase() }))
            .setContentText(getString(R.string.incoming_call_text, name))
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setAutoCancel(false)
            // Android 14+ may restrict full-screen intent. Answer remains a direct user click.
            .setFullScreenIntent(answerPending, true)
            .addAction(android.R.drawable.ic_menu_call, getString(R.string.action_answer), answerPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.action_decline), declinePending)
            .build()
    }

    private fun acquireWakeLock() {
        try {
            val power = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BharathLink:IncomingCall").apply {
                acquire(RING_TIMEOUT_MS)
            }
        } catch (ex: Exception) { Log.w(TAG, "Wake lock unavailable", ex) }
    }

    private fun startRinging() {
        try {
            ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
            ringtone?.play()
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            val pattern = longArrayOf(0, 500, 500)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        } catch (ex: Exception) { Log.w(TAG, "Ringtone unavailable", ex) }
    }

    private fun stopAlert() {
        handler.removeCallbacks(timeoutRunnable)
        ringtone?.stop()
        vibrator?.cancel()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        ringtone = null
        vibrator = null
        wakeLock = null
    }

    private fun stopCallAndSelf() {
        stopAlert()
        CallStateStore.clear(this)
        currentCallId = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, getString(R.string.channel_incoming_calls),
                NotificationManager.IMPORTANCE_HIGH).apply {
                description = getString(R.string.channel_incoming_calls_desc)
                enableVibration(false) // Custom ringtone is played while alert is active.
                setSound(null, null)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopAlert()
        CallStateStore.clear(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
