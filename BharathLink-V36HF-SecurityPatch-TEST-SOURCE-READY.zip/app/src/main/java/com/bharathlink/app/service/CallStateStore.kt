package com.bharathlink.app.service

import android.content.Context

/** TEST-only one-shot Answer intent validation; not a network call authorization system. */
object CallStateStore {
    private const val STORE = "bharathlink_pending_call_v36hf"
    private const val KEY_ID = "id"
    private const val KEY_EXPIRY = "expiry"
    private const val MAX_AGE_MS = 60_000L

    fun setPendingCall(context: Context, id: String) {
        context.getSharedPreferences(STORE, Context.MODE_PRIVATE).edit()
            .putString(KEY_ID, id)
            .putLong(KEY_EXPIRY, System.currentTimeMillis() + MAX_AGE_MS)
            .apply()
    }

    fun consumePendingCall(context: Context, id: String): Boolean {
        val prefs = context.getSharedPreferences(STORE, Context.MODE_PRIVATE)
        val matching = id.isNotBlank() && prefs.getString(KEY_ID, null) == id &&
            System.currentTimeMillis() <= prefs.getLong(KEY_EXPIRY, 0L)
        return matching && prefs.edit().clear().commit()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(STORE, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
