package com.bharathlink.app.util

import org.junit.Assert.*
import org.junit.Test

class OriginPolicyTest {
    @Test fun exactTrustedOrigins() {
        for (origin in OriginPolicy.trustedOrigins) {
            assertTrue(OriginPolicy.isAllowedPageUrl(origin))
            assertTrue(OriginPolicy.isAllowedPageUrl("$origin/call?x=1"))
        }
    }

    @Test fun rejectsLookalikesAndUnknownTenants() {
        for (url in listOf(
            "https://evil.run.app", "https://evil.supabase.co",
            "https://bharathlink-20-test.netlify.app.evil.com",
            "https://bharathlink-20-test.netlify.app@evil.com/",
            "https://evil.com@bharathlink-20-test.netlify.app/",
            "http://bharathlink-20-test.netlify.app/",
            "https://bharathlink-20-test.netlify.app:8443/",
            "https://localhost:443/", "http://127.0.0.1:8080/",
            "javascript:alert(1)", "data:text/html,evil", "blob:https://bharathlink-20-test.netlify.app/id",
            "file:///android_asset/index.html", "about:blank", "",
        )) assertFalse("Trusted disallowed URL: $url", OriginPolicy.isAllowedPageUrl(url))
    }

    @Test fun externalSchemesLimited() {
        for (url in listOf("mailto:test@example.com", "tel:+911234567890", "upi://pay?pa=a@b", "https://example.org")) {
            assertTrue(url, OriginPolicy.isSafeExternalUrl(url))
        }
        for (url in listOf("file:///etc/passwd", "intent://pay", "javascript:alert(1)", "content://files/test")) {
            assertFalse(url, OriginPolicy.isSafeExternalUrl(url))
        }
    }
}
