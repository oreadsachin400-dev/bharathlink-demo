# V36HF Source Audit — 31 October 2026

## Scope and evidence

Inspected uploaded `BharathLink-Android-V36HF (1).zip` and patched only this Android source package. Did not inspect or update hosted frontend, existing GitHub branches, Supabase, Netlify, or physical device apps. This is **not** a complete production security audit.

| ID | Severity | Original issue | Patch | Evidence and residual risk |
|---|---|---|---|---|
| S-01 | Critical | `addJavascriptInterface` exposed token read/write/wipe and call actions to any frame; no source frame checking | Removed legacy JS interface; added origin-scoped WebMessage listener with isMainFrame and current-page-origin checks; secret APIs disabled | Static check PASS; Android runtime bridge and compatibility test still pending; trusted-site XSS remains a risk |
| S-02 | High | Origin allowlist used wildcard `run.app`, `web.app`, `supabase.co`, `firebaseapp.com`, plus localhost/data/blob | Replaced with two exact HTTPS TEST origins, no wildcard | 29 JVM policy checks PASS; future origin changes require review |
| S-03 | High | Initial `intent.dataString` loaded without origin validation | Initial URLs must match exact trusted origins; non-trusted schemes blocked | Static source check PASS, runtime deep-link test pending |
| S-04 | High | WebRTC resource grants lacked origin validation and allowed unrecognized resources | Require trusted top-level origin, allowed resource set, Android OS grants and async revalidation | Static check PASS, actual device test pending |
| S-05 | High | Android 14 phoneCall foreground service type requires telecom qualification; service didn't implement it | Changed to bounded `shortService` alert; removed restricted phoneCall/microphone service type | Android 14 build/runtime still unverified; background call reliability NOT solved |
| S-06 | Medium | Answer from Service used background `startActivity` and could be blocked; callId interpolated into JS | Notification direct activity PendingIntent, one-shot call-ID match, JSON-escaped Web event | Static checks PASS; Web frontend must handle event and may need ready handshake |
| S-07 | Medium | Android icon references missing from ZIP | Added vector app icon and updated manifest | XML parse PASS; resource compilation still pending |
| S-08 | Medium | Keystore initialized with destructive reset-on-error fallback; migration didn't verify commit before deleting old preferences | Removed automatic erase, verified migration commit before legacy deletion | Code inspection; storage behavior not tested on device |
| S-09 | Medium | Network debug trust allowed user CA roots and origin restrictions were broad | Removed debug trust overrides | XML parse PASS; verify TEST HTTPS certificates on device |
| S-10 | Medium | Missing executable Gradle wrapper files and no packaged CI route | Added GitHub Actions Gradle 8.6 + SDK34 test/build workflow | CI NOT RUN; APK remains unavailable until successful runner build |
| S-11 | Medium | `release` used debug signing config | Removed explicit debug signing config for release | Build/run release NOT VERIFIED; no production signing or readiness |

## Important remaining risks / blockers

1. **Hosted frontend compatibility (release blocker):** JavaScript token APIs are disabled by design. Native bridge responses are asynchronous. The current web app may require changes; this ZIP contains no web code to migrate and test.
2. **Backend-origin authority (release blocker):** Allowlisted web origin is not proof of authenticated session or authorized signaling. Server-signed/replay-protected call events are not implemented; test-only call alert can still be triggered by compromised allowed page scripts.
3. **Android build and device test (release blocker):** No Android SDK/Gradle in this execution environment. No new APK was built or installed. Run GitHub CI, correct any compilation errors, and validate OS/device behavior.
4. **Background incoming calling:** `shortService` supports a short foreground notification and ringing, not VoIP long-running audio. Android 12–16 background start restrictions and full-screen intent eligibility require appropriate FCM/Telecom integration and device testing.
5. **WebRTC and file upload:** Actual two-phone calling, media permission behavior, file chooser/upload, camera switching, audio routing and screen locked behavior are not validated. Camera-switch native action removed until a verified frontend protocol exists.
6. **Secrets:** Android Keystore helper is not connected to the hosted web app. WebView localStorage/session cookies remain separate; app does not ensure origin-held tokens are hardware-protected.
7. **Other app modules:** Messaging/E2EE, BharathMail, payments, real identity/UPI/KYC verification, AI, notifications, daily reports, and Supabase access controls were not tested in this source patch.
8. **CI chain:** Never merge to main or distribute as production without an independently audited build, build provenance, two-device results and backend/authority approvals.

**Conclusion:** Offline hardening of TEST source completed; production readiness **NOT APPROVED**.

## Additional guardrails

- External browser/app navigation now requires a user gesture (where the Android WebView signals one).
- TEST incoming-call start actions are limited to one per five seconds per active bridge instance; an authenticated server-side call-event protocol remains required.
- The native WebMessage listener drops malformed/non-string or oversized messages; the compatibility shim times out pending Promise calls.

## GitHub branch comparison (read-only verified)

Connected repository: `oreadsachin400-dev/bharathlink-demo`; branch: `bharathlink-android-test-build` (existing). Its Android app actually resides under `BharathLink-Android/` and is a **different** Java/Groovy wrapper:

- Current GitHub `BharathLink-Android/app/src/main/java/in/bharathlink/demo/MainActivity.java` loads `https://bharathlink-20-test.netlify.app/`.
- Current GitHub `BharathLink-Android/app/build.gradle` uses `namespace 'in.bharathlink.demo'`, `compileSdk 35`, and `applicationId 'in.bharathlink.test.ci'`.
- Current GitHub `.github/workflows/build-android-test.yml` builds that `BharathLink-Android` directory and packages `BharathLink-TEST.apk`.
- Uploaded V36HF ZIP is a **separate Kotlin/Gradle-KTS source tree** with `com.bharathlink.app` and Android SDK 34 target. It cannot simply be copied over the existing Java wrapper without planning package identity, resource migration, feature preservation, Gradle/plugin compatibility and regression tests.

**No GitHub branches or deployed apps were changed.** The safer next action is to plan/implement a non-breaking integration into the existing TEST codebase, with an explicit CI build and two-phone validation, rather than overwriting the working TEST APK project.
