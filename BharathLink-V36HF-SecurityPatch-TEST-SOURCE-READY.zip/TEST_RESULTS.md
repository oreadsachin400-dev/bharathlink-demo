# V36HF Security-Patch Test Results — 31 October 2026

| Test group | Result | Method | Scope |
|---|---|---|---|
| Offline static/source assertions | **34/34 PASS** | `python scripts/run_static_checks.py` | XML validity, legacy bridge removed, exact-host policy assertions, manifest/resources, CI presence, Keystore fail-closed source checks |
| Pure Kotlin origin-policy cases | **29/29 PASS** | `kotlinc ... -include-runtime -d ... && java -jar ...` | Three permitted pages, 18 rejected page URLs, four allowed and four rejected external URLs |
| JUnit tests in Android CI | **NOT RUN** | `gradle :app:testDebugUnitTest` | Requires Gradle, Android SDK and fetched dependencies |
| Android APK compile | **NOT RUN** | `gradle :app:assembleDebug` | No Android SDK/Gradle available locally |
| Physical-device tests | **NOT RUN** | Two-device installation, login, WebRTC, notifications | Must be completed after APK build |
| Hosted web/API integration | **NOT RUN** | End-to-end frontend/bridge/signaling test | Hosted frontend not contained in source ZIP |

The 34 static checks confirm defined source properties, not runtime behavior. The 29 JVM checks cover only `OriginPolicy` logic. Earlier historical tests and APK builds are not attributed to this patched build.

**Reproduce the pure JVM origin checks:** Compile `app/src/main/java/com/bharathlink/app/util/OriginPolicy.kt` with a Kotlin CLI harness that asserts the allowed/denied URLs, or execute the included JUnit `OriginPolicyTest` after Gradle dependencies are installed.
